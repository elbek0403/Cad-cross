import React, { useState, useRef, useEffect } from 'react';
import { Upload, Download, BarChart3 } from 'lucide-react';

interface StationData {
  station: string;
  distance: number;
  elevation: number;
  description: string;
}

interface ChannelProfile {
  width: number;
  depth: number;
  leftSlope: number;
  rightSlope: number;
  waterLevel: number;
}

interface CrossSectionData {
  sta: string;
  distance: number;
  bottom: number;
  water: number;
  width: number;
  depth: number;
  description: string;
}

const ChannelSectionBuilder = () => {
  const [data, setData] = useState<CrossSectionData[]>([]);
  const [selectedSection, setSelectedSection] = useState<CrossSectionData | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const profileCanvasRef = useRef<HTMLCanvasElement>(null);

  // 📊 EXCEL FAYLNI PARSLA
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const arrayBuffer = await file.arrayBuffer();
      const workbook = XLSX.read(arrayBuffer, { type: 'array' });
      const worksheet = workbook.Sheets[workbook.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(worksheet);

      // ✅ TO'G'RI PARSING - Har bir satrni to'g'ri o'qiy olish
      const parsedData: CrossSectionData[] = rows
        .filter((row: any) => {
          // ПК2+00 formatini taniyi olish
          return row.A && /^ПК\d+/.test(String(row.A).trim());
        })
        .map((row: any) => {
          const sta = String(row.A).trim();
          const distance = parseFloat(String(row.B)) || 0;
          const bottom = parseFloat(String(row.C)) || 0;
          const description = String(row.D || '').trim();

          return {
            sta,
            distance,
            bottom,
            water: bottom + 1.5, // Standart suv chuqurligi
            width: 10, // Standart kanalning ensi
            depth: 2, // Standart chuqurligi
            description
          };
        })
        .sort((a, b) => a.distance - b.distance);

      setData(parsedData);
      if (parsedData.length > 0) {
        setSelectedSection(parsedData[0]);
      }
    } catch (error) {
      alert('Excel faylni o\'qishda xato: ' + error);
    }
  };

  // 🎨 KONDALANG KESIM CHIZISH (CROSS-SECTION)
  const drawCrossSection = (ctx: CanvasRenderingContext2D, section: CrossSectionData) => {
    const width = 600;
    const height = 400;
    const padding = 50;

    // Fon (oq)
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, width, height);

    // O'lcham o'qlar (koordinata)
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(padding, height - padding);
    ctx.lineTo(width - padding, height - padding);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(padding, padding);
    ctx.lineTo(padding, height - padding);
    ctx.stroke();

    // Trapezoid shakli chizish
    const centerX = width / 2;
    const baseLine = height - padding - 150; // Poydevor
    const waterLine = baseLine - (section.water - section.bottom) * 20; // Suv sathiy

    // ✅ TO'G'RI TRAPEZOID GEOMETRIYASI
    const leftBase = centerX - (section.width / 2) * 20;
    const rightBase = centerX + (section.width / 2) * 20;
    const leftTop = centerX - ((section.width / 2) + section.depth * section.leftSlope * 0.5) * 20;
    const rightTop = centerX + ((section.width / 2) + section.depth * section.rightSlope * 0.5) * 20;
    const topLine = baseLine - section.depth * 20;

    // Yer/Poydevor (QO'NG - Qizil)
    ctx.strokeStyle = '#FF0000';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(leftBase, baseLine);
    ctx.lineTo(leftTop, topLine);
    ctx.lineTo(centerX, topLine);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(rightBase, baseLine);
    ctx.lineTo(rightTop, topLine);
    ctx.lineTo(centerX, topLine);
    ctx.stroke();

    // Poydevor kesimi (QIZIL - RED)
    ctx.strokeStyle = '#FF0000';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(leftBase, baseLine);
    ctx.lineTo(rightBase, baseLine);
    ctx.stroke();

    // Yon eğimlari (YASHIL - GREEN)
    ctx.strokeStyle = '#00AA00';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(leftBase, baseLine);
    ctx.lineTo(leftTop, topLine);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(rightBase, baseLine);
    ctx.lineTo(rightTop, topLine);
    ctx.stroke();

    // Suv sathiy (KO'K - BLUE)
    ctx.strokeStyle = '#0000FF';
    ctx.lineWidth = 2;
    ctx.setLineDash([5, 5]);
    ctx.beginPath();
    ctx.moveTo(leftBase - 50, waterLine);
    ctx.lineTo(rightBase + 50, waterLine);
    ctx.stroke();
    ctx.setLineDash([]);

    // Suv to'ldirish (KO'K SHAFFOF)
    ctx.fillStyle = 'rgba(0, 0, 255, 0.1)';
    ctx.beginPath();
    ctx.moveTo(leftBase, baseLine);
    ctx.lineTo(rightBase, baseLine);
    ctx.lineTo(rightBase - 50, waterLine);
    ctx.lineTo(leftBase + 50, waterLine);
    ctx.closePath();
    ctx.fill();

    // TEKST VA O'LCHAM
    ctx.fillStyle = '#000000';
    ctx.font = 'bold 14px Arial';
    ctx.fillText(`Stantsiya: ${section.sta}`, 30, 30);
    ctx.fillText(`Poydevor: ${section.bottom.toFixed(2)} m`, 30, 60);
    ctx.fillText(`Suv: ${section.water.toFixed(2)} m`, 30, 90);
    ctx.fillText(`Eni: ${section.width.toFixed(1)} m`, 30, 120);
    ctx.fillText(`Chuqurligi: ${section.depth.toFixed(1)} m`, 30, 150);

    if (section.description) {
      ctx.font = '12px Arial';
      ctx.fillText(`Eslatma: ${section.description}`, 30, 180);
    }

    // O'LCHAM SHTRIXLARI
    ctx.strokeStyle = '#666666';
    ctx.lineWidth = 1;

    // Kenglikni o'lchamlash
    ctx.beginPath();
    ctx.moveTo(leftBase, baseLine + 20);
    ctx.lineTo(rightBase, baseLine + 20);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(leftBase, baseLine + 15);
    ctx.lineTo(leftBase, baseLine + 25);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(rightBase, baseLine + 15);
    ctx.lineTo(rightBase, baseLine + 25);
    ctx.stroke();

    ctx.fillStyle = '#666666';
    ctx.font = '11px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(`${section.width.toFixed(1)} m`, (leftBase + rightBase) / 2, baseLine + 50);
  };

  // 📈 BO'YLAMA KESIM (LONGITUDINAL SECTION)
  const drawLongitudinalSection = (ctx: CanvasRenderingContext2D) => {
    if (data.length === 0) return;

    const width = 1000;
    const height = 500;
    const padding = 80;
    const graphWidth = width - 2 * padding;
    const graphHeight = height - 2 * padding;

    // Fon
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, width, height);

    // O'qlar
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(padding, height - padding);
    ctx.lineTo(width - padding, height - padding);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(padding, padding);
    ctx.lineTo(padding, height - padding);
    ctx.stroke();

    // Min-Max elevatsiyalar
    const minElevation = Math.min(...data.map(d => d.bottom));
    const maxElevation = Math.max(...data.map(d => Math.max(d.water, d.bottom + 3)));
    const elevationRange = maxElevation - minElevation;

    // GRID VA O'LCHAM O'QI
    ctx.strokeStyle = '#e0e0e0';
    ctx.lineWidth = 0.5;
    ctx.font = '10px Arial';
    ctx.fillStyle = '#666666';
    ctx.textAlign = 'right';

    for (let i = 0; i <= 10; i++) {
      const elevation = minElevation + (elevationRange * i) / 10;
      const y = height - padding - (graphHeight * i) / 10;

      ctx.beginPath();
      ctx.moveTo(padding - 5, y);
      ctx.lineTo(width - padding, y);
      ctx.stroke();

      ctx.fillText(elevation.toFixed(1), padding - 10, y + 5);
    }

    // POYDEVOR CHIZIGI (QIZIL)
    ctx.strokeStyle = '#FF0000';
    ctx.lineWidth = 3;
    ctx.beginPath();

    data.forEach((station, index) => {
      const x = padding + (graphWidth * index) / (data.length - 1 || 1);
      const y = height - padding - ((station.bottom - minElevation) / elevationRange) * graphHeight;

      if (index === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    });

    ctx.stroke();

    // SUV SATHIY CHIZIGI (KO'K)
    ctx.strokeStyle = '#0000FF';
    ctx.lineWidth = 2;
    ctx.setLineDash([5, 5]);
    ctx.beginPath();

    data.forEach((station, index) => {
      const x = padding + (graphWidth * index) / (data.length - 1 || 1);
      const y = height - padding - ((station.water - minElevation) / elevationRange) * graphHeight;

      if (index === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    });

    ctx.stroke();
    ctx.setLineDash([]);

    // YER SATHIY (YASHIL)
    ctx.strokeStyle = '#00AA00';
    ctx.lineWidth = 2;
    ctx.beginPath();

    data.forEach((station, index) => {
      const x = padding + (graphWidth * index) / (data.length - 1 || 1);
      const y = height - padding - ((station.water + 0.5 - minElevation) / elevationRange) * graphHeight;

      if (index === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }
    });

    ctx.stroke();

    // ✅ HAR BIR STANTSIYADA VERTIKAL KESIM CHIZISH
    ctx.strokeStyle = '#cccccc';
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 3]);

    data.forEach((station, index) => {
      const x = padding + (graphWidth * index) / (data.length - 1 || 1);
      ctx.beginPath();
      ctx.moveTo(x, padding);
      ctx.lineTo(x, height - padding);
      ctx.stroke();
    });

    ctx.setLineDash([]);

    // STANTSIYALARNI BELGILASH (TUGUN NUQTALARI)
    data.forEach((station, index) => {
      const x = padding + (graphWidth * index) / (data.length - 1 || 1);
      const y = height - padding - ((station.bottom - minElevation) / elevationRange) * graphHeight;

      // Qizil nuqta poydevorda
      ctx.fillStyle = '#FF0000';
      ctx.beginPath();
      ctx.arc(x, y, 4, 0, Math.PI * 2);
      ctx.fill();

      // Stantsiya nomi
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 10px Arial';
      ctx.textAlign = 'center';
      ctx.fillText(station.sta, x, height - padding + 20);
    });

    // NOMLANISH VA LEGENDA
    ctx.fillStyle = '#000000';
    ctx.font = 'bold 16px Arial';
    ctx.textAlign = 'left';
    ctx.fillText('BO\'YLAMA KESIM (LONGITUDINAL SECTION)', padding, 25);

    // LEGENDA
    const legendX = width - 280;
    const legendY = 100;

    ctx.font = 'bold 12px Arial';
    ctx.fillText('LEGENDA:', legendX, legendY);

    // Qizil chiziq
    ctx.strokeStyle = '#FF0000';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(legendX, legendY + 20);
    ctx.lineTo(legendX + 30, legendY + 20);
    ctx.stroke();
    ctx.fillStyle = '#000000';
    ctx.font = '11px Arial';
    ctx.fillText('Poydevor', legendX + 40, legendY + 25);

    // Ko'k chiziq
    ctx.strokeStyle = '#0000FF';
    ctx.lineWidth = 2;
    ctx.setLineDash([5, 5]);
    ctx.beginPath();
    ctx.moveTo(legendX, legendY + 45);
    ctx.lineTo(legendX + 30, legendY + 45);
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = '#000000';
    ctx.font = '11px Arial';
    ctx.fillText('Suv sathiy', legendX + 40, legendY + 50);

    // Yashil chiziq
    ctx.strokeStyle = '#00AA00';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(legendX, legendY + 70);
    ctx.lineTo(legendX + 30, legendY + 70);
    ctx.stroke();
    ctx.fillStyle = '#000000';
    ctx.font = '11px Arial';
    ctx.fillText('Yer sathiy', legendX + 40, legendY + 75);
  };

  // CANVAS'NI CHIZISH
  useEffect(() => {
    if (canvasRef.current && selectedSection) {
      const ctx = canvasRef.current.getContext('2d');
      if (ctx) {
        drawCrossSection(ctx, selectedSection);
      }
    }
  }, [selectedSection]);

  useEffect(() => {
    if (profileCanvasRef.current && data.length > 0) {
      const ctx = profileCanvasRef.current.getContext('2d');
      if (ctx) {
        drawLongitudinalSection(ctx);
      }
    }
  }, [data]);

  // DWG EXPORT PLACEHOLDER
  const exportToDWG = () => {
    // Haqiqiy DWG yaratish uchun dxf library kerak
    const dxfContent = generateDXFContent();
    const blob = new Blob([dxfContent], { type: 'application/octet-stream' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'canal_section.dxf';
    a.click();
  };

  const generateDXFContent = () => {
    let dxf = '0\nSECTION\n2\nHEADER\n999\nDXF FILE CREATED BY CROSSCAD\n0\nENDSEC\n0\nSECTION\n2\nENTITIES\n';

    data.forEach((station) => {
      // TEXT
      dxf += `0\nTEXT\n8\nSTATION\n10\n0\n20\n${station.distance}\n40\n2.5\n1\n${station.sta}\n0\nLINE\n8\nPOYDEVOR\n10\n${-station.width / 2}\n20\n${station.bottom}\n11\n${station.width / 2}\n21\n${station.bottom}\n`;
    });

    dxf += '0\nENDSEC\n0\nEOF\n';
    return dxf;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 p-8">
      <div className="max-w-7xl mx-auto">
        {/* HEADER */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">🏗️ CrossCAD - Kanal Kesim Quruvchi</h1>
          <p className="text-gray-300">Excel-dan ma'lumotlarni o'qib, kondalang va bo'ylama kesimlarni chizish</p>
        </div>

        {/* FILE UPLOAD */}
        <div className="bg-slate-800 rounded-lg p-6 mb-8 border border-slate-700">
          <label className="flex items-center gap-3 cursor-pointer bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg w-fit transition">
            <Upload size={20} />
            <span>Excel faylini yuklash</span>
            <input
              type="file"
              accept=".xlsx,.xls"
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>
          {data.length > 0 && <p className="text-green-400 mt-3">✓ {data.length} ta stantsiya o'qildi</p>}
        </div>

        {/* KONDALANG KESIM */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          <div className="lg:col-span-2 bg-slate-800 rounded-lg p-6 border border-slate-700">
            <h2 className="text-xl font-bold text-white mb-4">📐 Kondalang Kesim (Cross-Section)</h2>
            <canvas
              ref={canvasRef}
              width={600}
              height={400}
              className="border border-slate-600 rounded w-full bg-white"
            />
          </div>

          {/* STANTSIYA TANLASH */}
          <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
            <h3 className="text-lg font-bold text-white mb-4">🎯 Stantsiyalarnı Tanlang</h3>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {data.map((station, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedSection(station)}
                  className={`w-full text-left px-4 py-3 rounded transition ${
                    selectedSection?.sta === station.sta
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-700 text-gray-300 hover:bg-slate-600'
                  }`}
                >
                  <div className="font-bold">{station.sta}</div>
                  <div className="text-xs mt-1">H = {station.bottom.toFixed(2)} m</div>
                  {station.description && <div className="text-xs text-gray-400">{station.description}</div>}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* BO'YLAMA KESIM */}
        <div className="bg-slate-800 rounded-lg p-6 border border-slate-700 mb-8">
          <h2 className="text-xl font-bold text-white mb-4">📈 Bo'ylama Kesim (Longitudinal Profile)</h2>
          <canvas
            ref={profileCanvasRef}
            width={1000}
            height={500}
            className="border border-slate-600 rounded w-full bg-white"
          />
        </div>

        {/* EXPORT BUTTONS */}
        <div className="flex gap-4">
          <button
            onClick={exportToDWG}
            className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg transition"
          >
            <Download size={20} />
            DXF Export (AutoCAD)
          </button>
          <button
            onClick={() => {
              const link = document.createElement('a');
              link.href = canvasRef.current?.toDataURL() || '';
              link.download = 'cross_section.png';
              link.click();
            }}
            className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg transition"
          >
            <BarChart3 size={20} />
            PNG Download
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChannelSectionBuilder;
