const { app, BrowserWindow, Menu, dialog, ipcMain } = require('electron');
const path = require('path');
const isDev = require('electron-is-dev');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1600,
    height: 1000,
    minWidth: 1000,
    minHeight: 700,
    backgroundColor: '#141a22',
    icon: path.join(__dirname, 'assets/icon.png'),
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      preload: path.join(__dirname, '..', 'preload.js'),
      enableRemoteModule: false,
    },
  });

  const startUrl = isDev
    ? 'http://localhost:5173'
    : `file://${path.join(__dirname, '../dist/index.html')}`;

  mainWindow.loadURL(startUrl);

  if (isDev) {
    mainWindow.webContents.openDevTools();
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  // Application Menu
  createMenu();
}

function createMenu() {
  const template = [
    {
      label: 'File',
      submenu: [
        {
          label: 'Chiqish',
          accelerator: 'CmdOrCtrl+Q',
          click: () => {
            app.quit();
          },
        },
      ],
    },
    {
      label: 'Edit',
      submenu: [
        { role: 'undo' },
        { role: 'redo' },
        { type: 'separator' },
        { role: 'cut' },
        { role: 'copy' },
        { role: 'paste' },
      ],
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { role: 'forceReload' },
        { role: 'toggleDevTools' },
        { type: 'separator' },
        { role: 'resetZoom' },
        { role: 'zoomIn' },
        { role: 'zoomOut' },
      ],
    },
    {
      label: 'Help',
      submenu: [
        {
          label: 'About CrossCAD',
          click: () => {
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'CrossCAD - Kanal Kesim Quruvchi',
              message: 'CrossCAD v2.0',
              detail:
                'Excel-dan kanal engineering ma\'lumotlarini o\'qib, kondalang va bo\'ylama kesimlarni avtomatik chizaydigan ilovasi.\n\n© 2026 CrossCAD Team',
            });
          },
        },
      ],
    },
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
}

// IPC Handlers

// Fayl tanlash
ipcMain.handle('select-file', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [
      { name: 'Excel Files', extensions: ['xlsx', 'xls'] },
      { name: 'All Files', extensions: ['*'] },
    ],
  });
  return result.filePaths[0] || null;
});

// DXF Saqlash
ipcMain.handle('save-dxf', async (event, dxfContent) => {
  const result = await dialog.showSaveDialog(mainWindow, {
    filters: [{ name: 'DXF Files', extensions: ['dxf'] }],
    defaultPath: 'canal_section.dxf',
  });

  if (!result.canceled) {
    const fs = require('fs');
    fs.writeFileSync(result.filePath, dxfContent);
    return result.filePath;
  }
  return null;
});

// PNG Saqlash
ipcMain.handle('save-png', async (event, canvasData) => {
  const result = await dialog.showSaveDialog(mainWindow, {
    filters: [{ name: 'PNG Files', extensions: ['png'] }],
    defaultPath: 'cross_section.png',
  });

  if (!result.canceled) {
    const fs = require('fs');
    const base64Data = canvasData.replace(/^data:image\/png;base64,/, '');
    fs.writeFileSync(result.filePath, base64Data, 'base64');
    return result.filePath;
  }
  return null;
});

// App Events
app.on('ready', createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (mainWindow === null) {
    createWindow();
  }
});

// Single instance check
const gotTheLock = app.requestSingleInstanceLock();

if (!gotTheLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });
}
