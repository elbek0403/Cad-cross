import React, { useState, useRef, useEffect } from 'react';
import { Upload, Download, BarChart3, AlertCircle, CheckCircle } from 'lucide-react';
import ChannelSectionBuilder from './components/ChannelSectionBuilder';
import { parseAnyFile, type ExcelParseResult } from './utils/excelParser';

type AppState = 'idle' | 'loading' | 'success' | 'error';

interface ErrorMessage {
  title: string;
  message: string;
  details?: string[];
}

function App() {
  const [appState, setAppState] = useState<AppState>('idle');
  const [errorMsg, setErrorMsg] = useState<ErrorMessage | null>(null);
  const [parseResult, setParseResult] = useState<ExcelParseResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // File o'qish
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setAppState('loading');
    setErrorMsg(null);

    try {
      // Faylni parsing qilish (XLSX, CSV, JSON)
      const result = await parseAnyFile(file);

      setParseResult(result);

      if (result.success) {
        setAppState('success');
      } else {
        setAppState('error');
        setErrorMsg({
          title: 'Parsing Xatosi',
          message: result.error || 'Noma\'lum xato',
          details: result.warnings,
        });
      }
    } catch (error) {
      setAppState('error');
      setErrorMsg({
        title: 'Fayl O\'qish Xatosi',
        message: String(error),
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* HEADER */}
      <header className="bg-black/40 border-b border-slate-700/50 sticky top-0 z-50 backdrop-blur">
        <div className="max-w-7xl mx-auto px-8 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-white">
              🏗️ CrossCAD <span className="text-sm text-gray-400">v2.0</span>
            </h1>
            <p className="text-gray-400 text-sm">Kanal Kesim Quruvchi - Excel → AutoCAD</p>
          </div>
          <div className="text-right text-gray-400 text-sm">
            {parseResult?.success && (
              <div className="flex items-center gap-2">
                <CheckCircle size={16} className="text-green-500" />
                <span>{parseResult.data.length} ta stantsiya yuklandi</span>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* MAIN CONTENT */}
      <main className="max-w-7xl mx-auto px-8 py-8">
        {/* Agar hech qanday ma'lumot yo'q bo'lsa - Upload panel ko'rsatish */}
        {!parseResult?.success ? (
          <div className="space-y-6">
            {/* UPLOAD CARD */}
            <div className="bg-gradient-to-br from-slate-800 to-slate-700 rounded-lg p-8 border border-slate-700/50">
              <div className="flex flex-col items-center justify-center min-h-64">
                <div className="mb-6">
                  <div className="w-24 h-24 bg-blue-500/10 rounded-full flex items-center justify-center border-2 border-blue-500/20">
                    <Upload size={48} className="text-blue-400" />
                  </div>
                </div>

                <h2 className="text-2xl font-bold text-white mb-2">Excel Faylini Yuklang</h2>
                <p className="text-gray-400 text-center max-w-md mb-8">
                  Kanal ma'lumotlarini o'z ichiga olgan Excel, CSV yoki JSON faylini yuklang
                </p>

                <label className="relative cursor-pointer">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".xlsx,.xls,.csv,.json"
                    onChange={handleFileUpload}
                    disabled={appState === 'loading'}
                    className="hidden"
                  />
                  <div className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 text-white px-8 py-4 rounded-lg font-semibold transition flex items-center gap-2">
                    <Upload size={20} />
                    {appState === 'loading' ? 'Yozilyapti...' : 'Faylni Tanlang'}
                  </div>
                </label>

                <p className="text-gray-500 text-sm mt-6">
                  Qabul qilinadigan formatlar: XLSX, CSV, JSON
                </p>
              </div>
            </div>

            {/* ERROR MESSAGE */}
            {errorMsg && (
              <div className="bg-red-900/20 border border-red-700/50 rounded-lg p-6">
                <div className="flex items-start gap-4">
                  <AlertCircle className="text-red-500 flex-shrink-0 mt-1" size={24} />
                  <div className="flex-1">
                    <h3 className="text-red-400 font-semibold mb-2">{errorMsg.title}</h3>
                    <p className="text-red-300/80 mb-3">{errorMsg.message}</p>
                    {errorMsg.details && errorMsg.details.length > 0 && (
                      <div className="bg-red-900/20 rounded p-3 text-sm text-red-300/60 max-h-32 overflow-y-auto">
                        {errorMsg.details.map((detail, idx) => (
                          <div key={idx}>• {detail}</div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* INSTRUCTIONS */}
            <div className="bg-slate-800/50 border border-slate-700/50 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-4">📋 Excel Fayl Format</h3>
              <div className="space-y-3 text-gray-300 text-sm">
                <p>Excel faylida quyidagi ustunlar bo'lishi kerak:</p>
                <div className="bg-slate-900/50 rounded p-4 overflow-x-auto">
                  <table className="w-full text-left">
                    <thead>
                      <tr className="border-b border-slate-700">
                        <th className="text-gray-400 font-semibold pb-2">Ustun</th>
                        <th className="text-gray-400 font-semibold pb-2">Tafsiri</th>
                        <th className="text-gray-400 font-semibold pb-2">Misol</th>
                      </tr>
                    </thead>
                    <tbody className="space-y-1">
                      <tr className="border-b border-slate-700/50">
                        <td className="py-2 text-blue-400 font-mono">A</td>
                        <td>Stantsiya nomi</td>
                        <td>ПК2+00</td>
                      </tr>
                      <tr className="border-b border-slate-700/50">
                        <td className="py-2 text-blue-400 font-mono">B</td>
                        <td>Masofa (m)</td>
                        <td>0</td>
                      </tr>
                      <tr className="border-b border-slate-700/50">
                        <td className="py-2 text-blue-400 font-mono">C</td>
                        <td>Poydevor balandligi (m)</td>
                        <td>381.03</td>
                      </tr>
                      <tr>
                        <td className="py-2 text-blue-400 font-mono">D</td>
                        <td>Eslatma/Tavsif</td>
                        <td>Gazоl труба</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Agar ma'lumot bo'lsa - ChannelSectionBuilder ko'rsatish */
          <ChannelSectionBuilder data={parseResult.data} />
        )}
      </main>

      {/* FOOTER */}
      <footer className="bg-black/40 border-t border-slate-700/50 mt-16 py-8">
        <div className="max-w-7xl mx-auto px-8">
          <div className="grid grid-cols-3 gap-8 text-sm text-gray-400 mb-6">
            <div>
              <h4 className="font-semibold text-white mb-2">Xususiyatlar</h4>
              <ul className="space-y-1 text-xs">
                <li>✓ Excel/CSV parsing</li>
                <li>✓ Kondalang kesim</li>
                <li>✓ Bo'ylama profil</li>
                <li>✓ DXF export</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-2">Formatlari</h4>
              <ul className="space-y-1 text-xs">
                <li>📊 XLSX</li>
                <li>📋 CSV</li>
                <li>📄 JSON</li>
                <li>🔧 DXF</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-white mb-2">Aloqa</h4>
              <ul className="space-y-1 text-xs">
                <li>Email: support@crosscad.dev</li>
                <li>GitHub: crosscad</li>
                <li>Version: 2.0.0</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-700/50 pt-6 text-center text-xs text-gray-500">
            <p>© 2026 CrossCAD Team - Kanal Engineering Ilovasi</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
