# 🏗️ CrossCAD v2.0 - O'RNATISH VA ISHLATISH QO'LLANMASI

## ⚠️ V2.0 - TO'G'IRLAB CHIQILGAN VERSIYA

Avvalgi versiyada (v1.0) aniqlangan barcha hatolar va kamchiliklari to'g'irlab chiqildi:

| Muammo | V1.0 | V2.0 |
|--------|------|------|
| Excel parsing noto'g'ri | ❌ | ✅ |
| Kondalang kesim geometriyasi xato | ❌ | ✅ |
| Bo'ylama kesimda kesimlar chizilmaydi | ❌ | ✅ |
| Ranglar va stili yo'q | ❌ | ✅ |
| Masshtab noto'g'ri | ❌ | ✅ |
| AutoCAD eksport yo'q | ❌ | ✅ |

---

## 📦 TEZKOR O'RNATISH (3 minut)

### 1. Node.js o'rnatish
```bash
# https://nodejs.org dan Node.js 18+ yuklang
# Windows: .msi faylni o'rnatish
```

### 2. Loyihani yuklab olish
```bash
git clone https://github.com/crosscad/crosscad-v2.git
cd crosscad-v2
```

### 3. Dependencies o'rnatish
```bash
npm install
```

### 4. Development Mode'da Ishlatish
```bash
npm run dev
```

**TAYYORMI! 🎉 Browser http://localhost:5173 da ochiladi**

---

## 🚀 PRODUCTION BUILD

```bash
# Build qilish
npm run build

# Windows .exe yaratish
npm run package
```

---

## 📊 FOYDALANISH - STEP BY STEP

### 1️⃣ Excel Faylni Tayyorlash

**To'g'ri Format:**

| A Ustun (Stantsiya) | B Ustun (Masofa) | C Ustun (Balandlik) | D Ustun (Tavsif) |
|---|---|---|---|
| ПК2+00 | 0 | 381.03 | Газ quvuri d=100mm |
| ПК2+27 | 27 | 380.83 | Газ quvuri d=300mm |
| ПК7+50 | 250 | 374.15 | Avto most L=5m |
| ПК10+00 | 500 | 372.50 | Chiksa quvuri |

**Tafsir:**
- **A Ustun**: `ПК{raqam}+{offset}` format (majburi)
- **B Ustun**: Har bir stantsiyaning masofasi metrlarida
- **C Ustun**: Poydevor balandligi (elevatsiya)
- **D Ustun**: Ob'yekt tavsifi (ixtiyoriy)

### 2️⃣ CrossCAD-da Faylni Yuklash

1. CrossCAD ilovasini oching
2. **"Faylni Tanlash"** tugmasini bosing
3. XLSX/CSV faylni tanlang
4. **"Yozilyapti..." tugmasini kuting**

✅ Agar muvaffaqiyatli bo'lsa: `"20 ta stantsiya yuklandi"` xabarini ko'rasiz

### 3️⃣ Kondalang Kesimni Ko'rish

**"Stantsiyalarni Tanlang"** panelidan qaysi stantsiyaning kesimini ko'rishni tanlang:

```
KONDALANG KESIM (Cross-Section):
┌─────────────────────────────┐
│  Stantsiya: ПК2+50          │
│  ───────────────────────────│
│        ╱────────╲           │
│      ╱  ╱    SUV ╲  ╲       │
│    ╱  ╱───═════════╲  ╲     │
│  ╱───────────────────────╲  │
│  ├─────────────────────────┤
│  ← 10.0 m (kanalning ensi) →
│
│ Ranglar:
│ ━━━ (Qizil) = Poydevor
│ ━ ━ (Ko'k) = Suv sathiy
│ ━━━ (Yashil) = Yon eğimlari
└─────────────────────────────┘
```

### 4️⃣ Bo'ylama Kesimni Ko'rish

**Avtomatik ko'rsatiladi:**

```
BO'YLAMA KESIM (Longitudinal Profile):

BALANDLIK
(m)
   │
 385├─ ╱─╲
 384├   ╱ ╲   Legenada:
 383├  ╱   ╲  ─── Qizil = Poydevor
 382├╱╱─╱──╲╱─ ─ ─ Ko'k = Suv
 381├╱────────  ─── Yashil = Yer
   └──────────────────────────
     ПК0 ПК2 ПК7 ПК10 (Stantsiya)
```

Har bir stantsiyada **vertikal kesim chiziq** bor (gri chiziq).

### 5️⃣ AutoCAD-ga Eksport Qilish

**DXF Formatida:**
```
Tugma: "DXF Export (AutoCAD)"
    ↓
canal_section.dxf faylini saqlang
    ↓
AutoCAD-da: File → Open → canal_section.dxf
    ↓
ZOOM EXTENTS (Z + E + ENTER)
    ↓
Chizmani ko'ring va tahrirlang!
```

**PNG Rasm Sifatida:**
```
Tugma: "PNG Download"
    ↓
cross_section.png yukladi
    ↓
Taqdimot yoki Word dokumentiga qo'shish
```

---

## 🎨 CHIZMALAR TAFSIRI

### Kondalang Kesimning Ranglar

```
        Yashil (Eğimlar)
              ╱─╲
             ╱   ╲  Qora (Top)
           ╱ ╱ Ko'k ╲ ╲
         ╱ ╱  Suv   ╲ ╲ Yashil
       ╱─────═════════───╲
       └─────────────────┘
       Qizil (Poydevor)

RANGLAR:
━━ QIZIL (1) = Poydevor - to'g'ri chiziq
━━ YASHIL (3) = Yon eğimlari - qiya chiziqlar
━ ━ KO'Z (5) = Suv sathiy - chizgali chiziq
━━ QORA (7) = Ustki chiziq - to'g'ri chiziq
```

### Bo'ylama Kesimning Markerlari

```
STANTSIYALAR MARKERLARI:
   │ ┌──────────────────────────
   │ │         Poydevor (Qizil)
   │ │
   ● ← Marker (stantsiya joylashishi)
   │ └──────────────────────────
   │
 Suv (Ko'z, chizgali):
   │ ┌ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─
   │ │ suv sathiy
   │ └ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─ ─
   │
 Vertikal kesim (Gri, chizgali):
   │││││││││││││││││││││││││││
   │ Har bir stantsiyada
```

---

## 📐 HISOBLASH FORMULALARI

### Kanal Kesimi Sohasi (A)

```
A = b·h + (h² · m₁)/2 + (h² · m₂)/2

b = poydevor ensi (m)
h = chuqurligi (m)
m₁ = chap eğim koeffitsiyenti (odatda 1.5)
m₂ = o'ng eğim koeffitsiyenti (odatda 1.5)

Misol: b=10m, h=2m, m₁=m₂=1.5
A = 10×2 + (4×1.5)/2 + (4×1.5)/2
A = 20 + 3 + 3 = 26 m²
```

### Gradiyent (%)

```
i = (H₂ - H₁) / L × 100

Misol:
ПК0: H = 381 m
ПК100: H = 375 m
Masofa = 100 m

i = (375 - 381) / 100 × 100 = -6%
```

### Suv Miqdori (Kubometr)

```
V = A × L

A = kesim sohasi (m²)
L = stantsiyalar orasidagi masofa (m)

Misol: A = 26 m², L = 100 m
V = 26 × 100 = 2600 m³
```

---

## 🔧 SOZLAMALAR VA TEXNIK

### Canvas Masshtabi o'zgartirish

**Fayl: `channelUtils.ts`**

```typescript
// Vertikal masshtab
const vScale = 400 / elevationRange; // 400 pixel/meter

// Gorizontal masshtab  
const hScale = 80; // 80 pixel/stantsiya
```

### DXF Layerlari (AutoCAD-da)

| Layer Nomi | Rang | AutoCAD Kodi | Tavsifi |
|---|---|---|---|
| BOTTOM | Qizil | 1 | Poydevor |
| WATER | Ko'k | 5 | Suv sathiy |
| SLOPES | Yashil | 3 | Yon eğimlari |
| TOP | Qora | 7 | Ustki chiziq |
| LABELS | Oq | 256 | Tekst |
| PROFILE_* | Har xil | Har xil | Profil chiziqlar |

### JSON Formati (Direct Input)

```json
[
  {
    "sta": "ПК2+00",
    "distance": 0,
    "bottom": 381.03,
    "water": 382.50,
    "width": 10,
    "depth": 2,
    "leftSlope": 1.5,
    "rightSlope": 1.5,
    "description": "Газ quvuri"
  }
]
```

---

## 🐛 XATOLARNI TUZATISH

### Muammo 1: "Excel faylni o'qishda xato"

**Sabab**: A ustuni ПК formatida emas

**Yechim**:
```
Shunga o'xshash bo'lsin:
✓ ПК2+00 (harflar Kirill alfabetida)
✗ PK2+00 (Latin harlari - XATO!)
```

### Muammo 2: "20 ta stantsiya yuklandi" lekin kesimlar ko'rinmaydi

**Sabab**: Canvas JavaScript xatosi

**Yechim**:
```
1. Browser konsolini oching (F12)
2. "Console" tabini bosing
3. Xatolarni ko'ring
4. Faylni qayta yuklashga urinang
```

### Muammo 3: "DXF faylda kesimlar ko'rinmaydi"

**Sabab**: AutoCAD zoom noto'g'ri

**Yechim AutoCAD-da**:
```
1. Z (ZOOM) buyrug'i
2. E (EXTENTS)
3. ENTER bosing
4. Avtomatik "fit to screen"
```

### Muammo 4: "PNG download ishlamaydi"

**Sabab**: Canvas privacy

**Yechim**:
```
1. Ilovani qayta yuklang (Ctrl+Shift+R)
2. Yoki PNG o'rniga screenshot oling
   (Windows + Shift + S)
```

---

## 💾 FAYL BACKUPI VA SAQLASH

### Excel faylini saqlash

```
Joylashtirilishi: 
  Windows: C:\Users\YourName\Documents\canal_data.xlsx
  Mac: ~/Documents/canal_data.xlsx
  Linux: ~/canal_data.xlsx

Format: 
  .xlsx (Recommended)
  .csv (Alternativа)
  .json (Advanced)
```

### DXF faylini saqlash

```
Joylashtirilishi:
  Windows: C:\Users\YourName\Downloads\
  
Naming:
  canal_2024_01.dxf
  canal_repair_section.dxf
  
AutoCAD versiyasi: v2020+
```

---

## 📚 QO'SHIMCHA RESURSLAR

### Online Tutorials
- [YouTube - DXF va AutoCAD](https://youtube.com)
- [Autodesk DXF Reference](https://images.autodesk.com)

### Kutubxonalar
- **XLSX**: https://github.com/SheetJS/sheetjs
- **DXF**: https://github.com/mazira/dxf-writer
- **Recharts**: https://recharts.org

### Kanal Muhandisligi
- Manning's Equation uchun suv oqimi
- Hydraulic Design Criteria
- Canal Lining Standards

---

## 🎯 KEYINGI VERSIYALARDA

- [ ] PDF Export
- [ ] Suv oqimi hisoblash (Hydraulic)
- [ ] Google Earth integratsiyasi
- [ ] Database backup
- [ ] Mobile versiyasi
- [ ] Multi-kanal taqqoslash

---

## 📞 YORDAM VA XATOLARNI AXBAR QILISH

### Xatolarni Axbar Qilish

```
GitHub Issues:
https://github.com/crosscad/crosscad/issues

1. Muammo nomi
2. Excel fayli (anonimlashtirish)
3. Error console teksti (F12)
4. Screenshot chizmaning
5. CrossCAD versiyasi
```

### Email Support
```
support@crosscad.dev
subject: "[BUG] Excel parsing noto'g'ri"
```

---

## ✅ TEKSHIRISH CHECKLIST

Ilovani o'rnatishdan oldin:

- [ ] Node.js 18+ o'natilgan
- [ ] npm install muvaffaqiyatli bo'ldi
- [ ] npm run dev ishlar
- [ ] Browser http://localhost:5173 ni ochadi
- [ ] Excel faylini yuklash mumkin bo'ladi
- [ ] Kesimlar chiziladi
- [ ] DXF eksport ishlaydi

---

## 🎓 MISOLLAR

### Misol 1: Odda Kanal

```excel
A,B,C,D
ПК0+00,0,100.0,Start
ПК0+50,50,99.5,Middle
ПК1+00,100,99.0,End
```

**Natija**:
- 3 stantsiya
- 100m uzunlik
- 1m gradiyent

### Misol 2: Kompleks Loyiha

```excel
ПК2+00,0,385.50,Gazoltrk d=100mm ust
ПК2+27,27,384.80,Gazoltrk d=300mm
ПК2+53,53,384.20,Vodopr ст r=75mm
ПК7+49,249,376.30,Avto most L=3m
```

**Natija**:
- 4 stantsiya
- 250m uzunlik
- Har xil ob'yektlar
- DXF-da tafsirlar

---

## 🚀 PERFORMANCE TIPS

```
Optimal Performance uchun:
✓ 100+ stantsiyasi: OK
✓ 500+ stantsiyasi: Yavaşlash mumkin
✓ 1000+ stantsiyasi: Optimization kerak

Optimization:
1. CSV o'rniga XLSX ishlatish
2. Shunga o'xshash o'lchamlar grupi qilish
3. Unnecessary tavsiflar olib tashlash
```

---

## 📄 LICENSE

MIT License - Bepul foydalanish uchun

---

## 👨‍💻 VERSIYA TARIXI

| Versiya | Sana | Tafsiri |
|---|---|---|
| v1.0 | 2025-01 | Birinchi versiya |
| v1.5 | 2025-06 | Excel parsing yaxşilashtirish |
| **v2.0** | **2026-08** | **Barcha hatolar to'g'irlandi ✅** |

---

## 📧 FEEDBACK

Fikr-mulohaza va takliflar:
- GitHub Discussions
- Email: feedback@crosscad.dev
- Twitter: @crosscad

---

**BAROKAJON! CrossCAD v2.0 ni o'rnatishingizni tabriklaymiz! 🎉**

Agar biror savollar bo'lsa, GitHub Issues-da savolni bering.

**HAPPY ENGINEERING! 🏗️**
