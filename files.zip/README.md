# 🏗️ CrossCAD - Kanal Kesim Quruvchi (v2.0 - TO'G'IRLAB CHIQILGAN)

## 📋 Umumiy Ma'lumot

CrossCAD — Excel-dan kanal engineering ma'lumotlarini o'qib, **ANIQ kondalang va bo'ylama kesimlarni** avtomatik chizaydigan Windows ilovasi.

### ✨ Yangi Versiyada To'g'irlab Chiqilgan Hatolar

1. ✅ **Excel Parsing** - Hamma satrlarni to'g'ri o'qiy oladi (ПК2+00, ПК7+50 formatini taniyi oladi)
2. ✅ **Kondalang Kesim Geometriyasi** - Trapezoid to'g'ri chiziladi (poydevor, eğimlar, suv sathiy)
3. ✅ **Bo'ylama Kesim** - Har bir stantsiyada vertikal kesimlar ko'rsatiladi
4. ✅ **Ranglar va Stili** - Qizil (poydevor), Ko'k (suv), Yashil (eğimlar)
5. ✅ **Masshtab va O'lcham** - Proportional va to'g'ri o'lchovlash
6. ✅ **AutoCAD Export** - DXF formatida chiqarish (AutoCAD-da ochish mumkin)

---

## 🚀 O'rnatish

### 1. Talablar
- Node.js 18+ (https://nodejs.org)
- npm yoki bun paket menejeri
- Windows, Mac, yoki Linux

### 2. Loyihani Klonlash

```bash
git clone <repository-url>
cd crosscad
npm install
```

### 3. Kutubxonalarni O'rnatish

```bash
npm install
# yoki
bun install
```

**Asosiy Kutubxonalar:**
- React 19 - UI framework
- Electron 43 - Desktop app
- Recharts - Grafikalar
- XLSX - Excel o'qish
- Tailwind CSS - Stiling
- Zod - Data validation

### 4. Development Mode'da Ishlatish

```bash
npm run dev
```

### 5. Build Qilish

```bash
npm run build
npm run build:electron
```

---

## 📊 Foydalanish Qo'llanmasi

### Excel Fayl Format

Ilovaga Excel faylni quyidagi strukturada tayyorlashingiz kerak:

| A Ustun | B Ustun | C Ustun | D Ustun |
|---------|---------|---------|---------|
| ПК2+00  | 0       | 381.03  | Газ тр d=100 мм |
| ПК2+27  | 27      | 380.83  | Газ тр d=300 мм |
| ПК2+53  | 53      | 380.83  | Вода-пр ст с=100 мм |
| ПК7+49  | 249     | 374.31  | Авто мост L=3 м |

**Ustunlar Tavsifi:**
- **A**: Stantsiya nomi (ПК + masofasi format)
- **B**: Masofa (metrlar)
- **C**: Poydevor balandligi/Elevatsiya (metrlar)
- **D**: Eslatma/Ob'yekt tavsifi

### Ilovani Ishlatish

1. **"Excel faylni yuklash"** tugmasini bosing
2. Siz yuklagan ma'lumot sahifada ko'rsatiladi
3. **"Kondalang Kesim"** - Har bir stantsiyaning yondan ko'rinishi chiziladi
4. **"Bo'ylama Kesim"** - Kanal profili (poydevor va suv sathiylarning o'zgarishi)
5. **"Stantsiya Tanlash"** - Qaysi stantsiyaning kondalang kesimini ko'rish kerakligini tanlang

### Export Qilish

#### DXF Formatida (AutoCAD)
```
Tugma: "DXF Export (AutoCAD)"
↓
Fayl: canal_section.dxf
↓
AutoCAD-da ochish
```

**DXF-da Ko'rinish:**
- BOTTOM (Qizil) - Poydevor
- WATER (Ko'k) - Suv sathiy
- SLOPES (Yashil) - Yon eğimlari
- LABELS (Oq) - Stantsiya nomlar va parametrlar

#### PNG Rasm Sifatida
```
Tugma: "PNG Download"
↓
Fayl: cross_section.png
↓
Taqdimot yoki hujjat'ga qo'shish
```

---

## 🎨 Chizmaning Xususiyatlari

### Kondalang Kesim (Cross-Section)

```
                    ╱─────╲
                   ╱  TO'P  ╲
              ╱  ╱         ╲  ╲
        SLOPES╱  ╱           ╲  ╲
            ╱  ╱   WATER      ╲  ╲
          ╱  ╱_____═════════════╲  ╲
        ╱  ╱                      ╲  ╲
      ╱──────────────────────────────╲
      ←────  BOTTOM (RED)  ──────→
      
      Tavsif:
      - Qizil chiziq: Poydevor
      - Ko'k chiziq: Suv sathiy
      - Yashil chiziq: Yon eğimlari
      - Ko'k shaffof: Suv to'ldirish
```

### Bo'ylama Kesim (Longitudinal Section)

```
ELEVATION (m)
    │
  385├─ ╱─╲
  384├   ╱ ╲─╲
  383├  ╱   ╲ ╲─╲
  382├╱╱─╱─╱╲╱─╲╱╲
  381├╱──────────────
  380├
    └──────────────────────── DISTANCE (m)
      ПК0 ПК2 ПК7 ПК10

      Tavsif:
      ─── Qizil: Poydevor
      ─ ─ Ko'k: Suv sathiy  
      │││ Gri chiziq: Vertikal kesimlar
      ● Marker: Stantsiya joylashishi
```

---

## 🔧 Texnik Tafsil

### Fayl Tuzilishi

```
crosscad/
├── src/
│   ├── components/
│   │   └── ChannelSectionBuilder.tsx    # Asosiy komponent
│   ├── utils/
│   │   ├── channelUtils.ts              # Hisoblash funksiyalar
│   │   └── dxfExporter.ts              # DXF export
│   └── App.tsx
├── electron/
│   └── main.cjs                         # Electron process
├── package.json
└── vite.config.ts                       # Build config
```

### Kalitli Funksiyalar

#### `calculateTrapezoidPoints()`
Kondalang kesim trapezoid nuqtalarini hisob qiladi.

```typescript
const points = calculateTrapezoidPoints(
  centerX, baseLine, 
  { width: 10, depth: 2, leftSlope: 1.5, rightSlope: 1.5 },
  scale
);
```

#### `calculateGraphY()` & `calculateGraphX()`
Bo'ylama kesimda koordinatalarni hisoblash.

```typescript
const y = calculateGraphY(elevation, minE, maxE, height, bottom);
const x = calculateGraphX(index, total, width, left);
```

#### `exportToDXF()`
DXF formatida eksport qilish.

```typescript
import { exportToDXF } from './dxfExporter';
exportToDXF(sections, 'my_canal');
```

---

## 📐 Formulalar

### Kanal Kesimi Sohasi (m²)

```
A = b·h + (h² · m₁)/2 + (h² · m₂)/2

Где:
  b = poydevor ensi (m)
  h = chuqurligi (m)
  m₁ = chap eğim koeffitsiyenti
  m₂ = o'ng eğim koeffitsiyenti
```

### Gradiyent (%)

```
i = (H₂ - H₁) / L × 100

Где:
  H₁, H₂ = elevatsiyalar (m)
  L = masofa (m)
```

### Suv Miqdori (m³)

```
V = A × L

Где:
  A = kesim sohasi (m²)
  L = stantsiyalar orasidagi masofa (m)
```

---

## ⚙️ Sozlamalar

### Canvas Masshtabi

Chizmaning o'lchamlini o'zgartirish:

```typescript
// channelUtils.ts -> calculateOptimalScale()
const vScale = elevationRange > 0 ? 400 / elevationRange : 1; // 400px vertikal
const hScale = 80; // 80px har stantsiya
```

### Ranglar

DXF-da LayerLar (AutoCAD):

| Layer | Rang | DXF Kodi |
|-------|------|----------|
| BOTTOM | Qizil | 1 |
| WATER | Ko'k | 5 |
| SLOPES | Yashil | 3 |
| LABELS | Oq | 256 |

### Faylning Nomi

```typescript
// dxfExporter.ts -> exportToDXF()
export function exportToDXF(
  sections: CrossSectionData[],
  filename: string = 'canal_section'  // O'zgarting
): void
```

---

## 🐛 Xatolarni Tuzatish

### Muammo: "Excel faylni o'qishda xato"
**Sabab**: Excel formati noto'g'ri
**Yechim**: 
1. Faylni `.xlsx` formatida saqlashingiz tekshiring
2. A ustunning ПК2+00 formatida ekanligini tekshiring
3. B-C ustunlar raqamlar bo'lishi kerak

### Muammo: "DXF faylda kesimlar ko'rinmaydi"
**Sabab**: AutoCAD-da shunga to'g'ri zoom qilishingiz kerak
**Yechim**:
1. AutoCAD-da `ZOOM EXTENTS` buyrug'ini ishlatung
2. yoki Layer'larni tekshiring (Layers panelida)

### Muammo: "Canvas'ta rasm chizilmaydi"
**Sabab**: JavaScript xatosi
**Yechim**:
1. Browser konsolini oching (F12)
2. Xatolarni ko'ring
3. Faylni qayta yuklashga urinang

---

## 📚 Qo'shimcha Kutubxonalar

### XLSX - Excel o'qish
```typescript
import XLSX from 'xlsx';
const workbook = XLSX.read(arrayBuffer, { type: 'array' });
```

### Recharts - Grafikalar
```typescript
import { LineChart, XAxis, YAxis, Line } from 'recharts';
```

### DXF Export
```typescript
import { exportToDXF } from './dxfExporter';
exportToDXF(sections, 'output');
```

---

## 🎯 Keyingi Imkoniyatlar

- [ ] PDF eksport
- [ ] Multi-kanal taqqoslash
- [ ] Suv hisobini (hydraulic) hisoblash
- [ ] Google Earth integratsiyasi
- [ ] Database bilan ulanish
- [ ] Mobile versiyasi

---

## 📧 Yordam va Muammo Axbarot

Agar biror muammo bo'lsa:
1. GitHub Issues'da xabar bering
2. ERROR loggini taqdim eting
3. Excel faylning misolini biling

---

## 📄 License

MIT License - Bepul foydalanish uchun

---

## 👨‍💻 Muallif

**CrossCAD Development Team**
- Version 2.0 (Fixed Edition)
- 2026

---

## 📞 Aloqa

- Email: support@crosscad.dev
- GitHub: https://github.com/crosscad
- Website: https://crosscad.dev

---

**O'ZINGIZDA ISHLATISP:**

```bash
# Klonlash
git clone ...

# O'rnatish
npm install

# Development
npm run dev

# Build
npm run build

# Export to DXF
# → Ilovada "DXF Export" tugmasini bosing
```

**BAROKAJON! 🎉**
