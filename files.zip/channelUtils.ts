/**
 * ChannelUtils - Kanal kesim hisob-kitoblari uchun utility moduliHold
 */

export interface Point {
  x: number;
  y: number;
}

export interface ChannelDimensions {
  width: number;
  depth: number;
  leftSlope: number;
  rightSlope: number;
}

export interface Elevation {
  station: string;
  distance: number;
  bottom: number;
  water: number;
}

/**
 * Trapezoid kesimini chizish uchun nuqtalarni hisoblash
 * @param centerX - Markaziy X koordinatasi
 * @param baseLine - Poydevor Y sathiy
 * @param dimensions - Kanal o'lchamlari
 * @param scale - Masshtab koeffitsiyenti
 * @returns Trapezoid nuqtalari
 */
export function calculateTrapezoidPoints(
  centerX: number,
  baseLine: number,
  dimensions: ChannelDimensions,
  scale: number = 20
): Point[] {
  const { width, depth, leftSlope, rightSlope } = dimensions;

  const leftBase = centerX - (width / 2) * scale;
  const rightBase = centerX + (width / 2) * scale;
  const leftTop = centerX - ((width / 2) + depth * leftSlope * 0.5) * scale;
  const rightTop = centerX + ((width / 2) + depth * rightSlope * 0.5) * scale;
  const topLine = baseLine - depth * scale;

  return [
    { x: leftBase, y: baseLine },
    { x: rightBase, y: baseLine },
    { x: rightTop, y: topLine },
    { x: leftTop, y: topLine },
  ];
}

/**
 * Su to'ldirish sohasi uchun nuqtalarni hisoblash
 * @param trapezoidPoints - Trapezoid nuqtalari
 * @param waterLevel - Suv sathiy (m)
 * @param bottomElev - Poydevor balandligi
 * @param scale - Masshtab
 * @returns Su sohasi nuqtalari
 */
export function calculateWaterArea(
  trapezoidPoints: Point[],
  waterLevel: number,
  bottomElev: number,
  scale: number = 20
): Point[] {
  const waterDepth = waterLevel - bottomElev;
  const waterY = trapezoidPoints[0].y - waterDepth * scale;

  const leftPoint = trapezoidPoints[0];
  const rightPoint = trapezoidPoints[1];

  return [
    leftPoint,
    rightPoint,
    { x: rightPoint.x - 50, y: waterY },
    { x: leftPoint.x + 50, y: waterY },
  ];
}

/**
 * Grafikda Y koordinatasi hisoblash
 * @param elevation - Balandlik qiymati (m)
 * @param minElevation - Minimal balandlik
 * @param maxElevation - Maksimal balandlik
 * @param graphHeight - Graf balandligi (pixels)
 * @param canvasBottom - Canvas ustungi Y koordinata
 * @returns Y koordinatasi
 */
export function calculateGraphY(
  elevation: number,
  minElevation: number,
  maxElevation: number,
  graphHeight: number,
  canvasBottom: number
): number {
  const range = maxElevation - minElevation;
  const normalized = (elevation - minElevation) / range;
  return canvasBottom - graphHeight * normalized;
}

/**
 * Grafikda X koordinatasi hisoblash (stantsiya bo'ylab)
 * @param index - Stantsiya indeksi
 * @param totalStations - Jami stantsiyalar soni
 * @param graphWidth - Graf ensligi (pixels)
 * @param canvasLeft - Canvas chap X koordinata
 * @returns X koordinatasi
 */
export function calculateGraphX(
  index: number,
  totalStations: number,
  graphWidth: number,
  canvasLeft: number
): number {
  if (totalStations <= 1) return canvasLeft + graphWidth / 2;
  return canvasLeft + (graphWidth * index) / (totalStations - 1);
}

/**
 * SVG path string yaratish kondalang kesim uchun
 */
export function createCrossSectionPath(
  points: Point[],
  scale: number = 20
): string {
  if (points.length === 0) return '';

  let path = `M ${points[0].x} ${points[0].y}`;
  for (let i = 1; i < points.length; i++) {
    path += ` L ${points[i].x} ${points[i].y}`;
  }
  path += ' Z';

  return path;
}

/**
 * SVG polyline yaratish profilsiz uchun
 */
export function createProfileLine(points: Point[]): string {
  if (points.length === 0) return '';

  return points.map((p, i) => `${p.x},${p.y}`).join(' ');
}

/**
 * DXF formatida chizish kodi
 */
export function generateDXFLine(
  x1: number,
  y1: number,
  x2: number,
  y2: number,
  layer: string = 'CHANNEL',
  color: number = 256
): string {
  return `0
LINE
5
0
8
${layer}
62
${color}
10
${x1}
20
${y1}
11
${x2}
21
${y2}
`;
}

/**
 * DXF tekst kodi
 */
export function generateDXFText(
  x: number,
  y: number,
  text: string,
  height: number = 2.5,
  layer: string = 'TEXT'
): string {
  return `0
TEXT
5
0
8
${layer}
10
${x}
20
${y}
40
${height}
1
${text}
`;
}

/**
 * DXF circle kodi
 */
export function generateDXFCircle(
  x: number,
  y: number,
  radius: number,
  layer: string = 'MARKER'
): string {
  return `0
CIRCLE
5
0
8
${layer}
10
${x}
20
${y}
40
${radius}
`;
}

/**
 * Excel ma'lumotlarini to'g'ri parsing qilish
 * @param rows - Excel satrlari
 * @returns Parsed ma'lumot
 */
export function parseExcelData(rows: any[]): any[] {
  return rows
    .filter((row) => {
      const stationId = String(row.A || '').trim();
      // ПК2+00, ПК7+50 kabi pattern
      return /^ПК\d+/.test(stationId);
    })
    .map((row) => {
      const sta = String(row.A).trim();
      const distance = parseFloat(String(row.B)) || 0;
      const elevation = parseFloat(String(row.C)) || 0;
      const description = String(row.D || '').trim();

      return {
        sta,
        distance,
        elevation,
        description,
      };
    })
    .sort((a, b) => a.distance - b.distance);
}

/**
 * Stantsiyalar orasida interpolyatsiya
 * @param prev - Avvalgi stantsiya
 * @param next - Keyingi stantsiya
 * @param ratio - Interpolyatsiya nisbati (0-1)
 * @returns Interpolyatsiyalangan balandlik
 */
export function interpolateElevation(
  prev: number,
  next: number,
  ratio: number
): number {
  return prev + (next - prev) * ratio;
}

/**
 * Gradiyentni hisoblash (%)
 * @param prevElev - Avvalgi balandlik
 * @param nextElev - Keyingi balandlik
 * @param distance - Masofasi (m)
 * @returns Gradient foizda
 */
export function calculateGradient(
  prevElev: number,
  nextElev: number,
  distance: number
): number {
  if (distance === 0) return 0;
  return ((nextElev - prevElev) / distance) * 100;
}

/**
 * Kanal kesim sohasi (m²)
 */
export function calculateChannelArea(
  width: number,
  depth: number,
  leftSlope: number,
  rightSlope: number
): number {
  const bottomArea = width * depth;
  const leftTriangle = (depth * depth * leftSlope) / 2;
  const rightTriangle = (depth * depth * rightSlope) / 2;
  return bottomArea + leftTriangle + rightTriangle;
}

/**
 * Kanal perimetri (m)
 */
export function calculateChannelPerimeter(
  width: number,
  depth: number,
  leftSlope: number,
  rightSlope: number
): number {
  const bottomLength = width;
  const leftLength = depth * Math.sqrt(1 + leftSlope * leftSlope);
  const rightLength = depth * Math.sqrt(1 + rightSlope * rightSlope);
  return bottomLength + leftLength + rightLength;
}

/**
 * Suv miqdori (m³) bir stantsiyada
 */
export function calculateWaterVolume(
  width: number,
  waterDepth: number,
  slope: number
): number {
  const bottomArea = width * waterDepth;
  const triangleArea = (waterDepth * waterDepth * slope) / 2;
  return bottomArea + triangleArea;
}

/**
 * RGB rangdan HEX ga
 */
export function rgbToHex(r: number, g: number, b: number): string {
  return '#' + [r, g, b].map(x => {
    const hex = x.toString(16);
    return hex.length === 1 ? '0' + hex : hex;
  }).join('');
}

/**
 * HEX rangdan RGB ga
 */
export function hexToRgb(hex: string): { r: number; g: number; b: number } | null {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return result ? {
    r: parseInt(result[1], 16),
    g: parseInt(result[2], 16),
    b: parseInt(result[3], 16),
  } : null;
}

/**
 * Masshtab sozlash (min-max elevatsiyalar uchun)
 */
export function calculateOptimalScale(
  elevations: number[]
): { vScale: number; hScale: number } {
  const minElev = Math.min(...elevations);
  const maxElev = Math.max(...elevations);
  const elevRange = maxElev - minElev;

  // Vertikal masshtab - har 1 meter = 50 pixels
  const vScale = elevRange > 0 ? 400 / elevRange : 1;

  // Gorizontal masshtab - har stantsiya = 80 pixels
  const hScale = 80;

  return { vScale, hScale };
}

/**
 * Canvas'ni chop etishga tayyorlash
 */
export function setupCanvasForPrint(
  canvas: HTMLCanvasElement,
  dpi: number = 300
): HTMLCanvasElement {
  const scale = dpi / 96; // 96 DPI standart ekran
  const printCanvas = document.createElement('canvas');
  const ctx = printCanvas.getContext('2d');

  if (!ctx) return canvas;

  printCanvas.width = canvas.width * scale;
  printCanvas.height = canvas.height * scale;

  ctx.scale(scale, scale);
  const originalCtx = canvas.getContext('2d');
  if (originalCtx) {
    ctx.drawImage(canvas, 0, 0);
  }

  return printCanvas;
}
