/**
 * DXF Exporter - AutoCAD formatida kesimlarni yaratish
 */

interface CrossSectionData {
  sta: string;
  distance: number;
  bottom: number;
  water: number;
  width: number;
  depth: number;
  description: string;
  leftSlope?: number;
  rightSlope?: number;
}

interface DXFLayer {
  name: string;
  color: number;
  lineType?: string;
}

class DXFExporter {
  private content: string = '';
  private entityCount: number = 0;

  /**
   * DXF faylni boshlash
   */
  public start(): void {
    this.content = this.getHeader();
    this.content += this.getTables();
  }

  /**
   * Bitta line chizish
   */
  public addLine(
    x1: number,
    y1: number,
    x2: number,
    y2: number,
    layer: string = 'CHANNEL',
    color: number = 256,
    lineType: string = 'CONTINUOUS'
  ): void {
    this.entityCount++;
    this.content += `0\nLINE\n5\n${this.entityCount.toString(16).toUpperCase()}\n`;
    this.content += `8\n${layer}\n`;
    this.content += `62\n${color}\n`;
    this.content += `6\n${lineType}\n`;
    this.content += `10\n${x1}\n20\n${y1}\n30\n0\n`;
    this.content += `11\n${x2}\n21\n${y2}\n31\n0\n`;
  }

  /**
   * Polyline chizish (ko'p nuqtalari chiziq)
   */
  public addPolyline(
    points: Array<{ x: number; y: number }>,
    layer: string = 'CHANNEL',
    color: number = 256,
    closed: boolean = false
  ): void {
    this.entityCount++;
    const polylineId = this.entityCount.toString(16).toUpperCase();

    this.content += `0\nLWPOLYLINE\n5\n${polylineId}\n`;
    this.content += `8\n${layer}\n`;
    this.content += `62\n${color}\n`;
    this.content += `90\n${points.length}\n`;
    this.content += `70\n${closed ? 1 : 0}\n`;

    points.forEach((point) => {
      this.content += `0\nLWPOLYLINE\n`;
      this.content += `10\n${point.x}\n20\n${point.y}\n30\n0\n`;
    });
  }

  /**
   * Circle chizish
   */
  public addCircle(
    x: number,
    y: number,
    radius: number,
    layer: string = 'MARKER',
    color: number = 256
  ): void {
    this.entityCount++;
    this.content += `0\nCIRCLE\n5\n${this.entityCount.toString(16).toUpperCase()}\n`;
    this.content += `8\n${layer}\n`;
    this.content += `62\n${color}\n`;
    this.content += `10\n${x}\n20\n${y}\n30\n0\n`;
    this.content += `40\n${radius}\n`;
  }

  /**
   * Text qo'shish
   */
  public addText(
    x: number,
    y: number,
    text: string,
    height: number = 2.5,
    layer: string = 'TEXT',
    color: number = 256,
    justify: number = 0
  ): void {
    this.entityCount++;
    this.content += `0\nTEXT\n5\n${this.entityCount.toString(16).toUpperCase()}\n`;
    this.content += `8\n${layer}\n`;
    this.content += `62\n${color}\n`;
    this.content += `10\n${x}\n20\n${y}\n30\n0\n`;
    this.content += `40\n${height}\n`;
    this.content += `1\n${text}\n`;
    this.content += `72\n${justify}\n`;
  }

  /**
   * Kondalang kesim chizish
   */
  public drawCrossSection(section: CrossSectionData): void {
    const startX = 0;
    const startY = section.distance * 10; // Masshtablash

    // Trapezoid nuqtalari
    const leftSlope = section.leftSlope || 1.5;
    const rightSlope = section.rightSlope || 1.5;
    const leftBase = startX - (section.width / 2);
    const rightBase = startX + (section.width / 2);
    const leftTop = startX - ((section.width / 2) + section.depth * leftSlope * 0.5);
    const rightTop = startX + ((section.width / 2) + section.depth * rightSlope * 0.5);
    const topLine = startY - section.depth;

    // Poydevor chiziq (QIZIL - Red)
    this.addLine(leftBase, startY, rightBase, startY, 'BOTTOM', 1, 'CONTINUOUS');

    // Yon eğimlari (YASHIL - Green)
    this.addLine(leftBase, startY, leftTop, topLine, 'SLOPES', 3, 'CONTINUOUS');
    this.addLine(rightBase, startY, rightTop, topLine, 'SLOPES', 3, 'CONTINUOUS');

    // Ustki chiziq (QORA - Black)
    this.addLine(leftTop, topLine, rightTop, topLine, 'TOP', 7, 'CONTINUOUS');

    // Suv sathiy (KO'K - Blue)
    const waterY = startY + (section.water - section.bottom) * 10;
    this.addLine(leftBase - 1, waterY, rightBase + 1, waterY, 'WATER', 5, 'DASHED');

    // Stantsiya nomi
    this.addText(startX, startY + 1.5, section.sta, 2.5, 'LABELS', 256);

    // Parametrlar
    const paramText = `W=${section.width.toFixed(1)}m D=${section.depth.toFixed(1)}m`;
    this.addText(startX, topLine - 1, paramText, 2.0, 'LABELS', 256);

    // Eslatma
    if (section.description) {
      this.addText(startX, topLine - 2.5, section.description, 1.5, 'NOTES', 256);
    }
  }

  /**
   * Bo'ylama kesim chizish
   */
  public drawLongitudinalProfile(sections: CrossSectionData[]): void {
    if (sections.length === 0) return;

    // Balandliklar to'plami
    const elevations = sections.map((s) => s.bottom);
    const minElev = Math.min(...elevations);
    const maxElev = Math.max(...elevations);
    const scale = 200 / (maxElev - minElev || 1); // Vertikal masshtab

    // Poydevor chiziq (QIZIL)
    const bottomPoints = sections.map((s, idx) => ({
      x: idx * 10,
      y: (s.bottom - minElev) * scale,
    }));

    this.addPolylinePoints(bottomPoints, 'PROFILE_BOTTOM', 1); // Qizil

    // Suv sathiy chiziq (KO'K)
    const waterPoints = sections.map((s, idx) => ({
      x: idx * 10,
      y: (s.water - minElev) * scale,
    }));

    this.addPolylinePoints(waterPoints, 'PROFILE_WATER', 5); // Ko'k

    // Vertikal kesimlar har bir stantsiyada
    sections.forEach((s, idx) => {
      const x = idx * 10;
      const bottomY = (s.bottom - minElev) * scale;
      const topY = (s.water + 0.5 - minElev) * scale;

      // Dashed chiziq
      this.addLine(x, 0, x, topY, 'PROFILE_DIVISIONS', 8, 'DASHED');

      // Stantsiya nomi
      this.addText(x, -2, s.sta, 2.0, 'PROFILE_LABELS', 256);

      // Marker nuqta
      this.addCircle(x, bottomY, 0.3, 'PROFILE_MARKERS', 1);
    });

    // Balandlik o'qi (Y axis)
    this.addLine(-1, 0, -1, (maxElev - minElev) * scale, 'PROFILE_AXIS', 0);

    // Balandlik belgilari
    for (let i = 0; i <= 10; i++) {
      const elev = minElev + ((maxElev - minElev) * i) / 10;
      const y = (elev - minElev) * scale;
      this.addLine(-1.2, y, -0.8, y, 'PROFILE_AXIS', 0);
      this.addText(-2, y, elev.toFixed(1), 1.5, 'PROFILE_LABELS', 256);
    }
  }

  /**
   * Polyline nuqtalari qo'shish (helper)
   */
  private addPolylinePoints(
    points: Array<{ x: number; y: number }>,
    layer: string,
    color: number
  ): void {
    if (points.length < 2) return;

    for (let i = 0; i < points.length - 1; i++) {
      this.addLine(
        points[i].x,
        points[i].y,
        points[i + 1].x,
        points[i + 1].y,
        layer,
        color,
        'CONTINUOUS'
      );
    }
  }

  /**
   * Legenda qo'shish
   */
  public addLegend(): void {
    const legendX = -20;
    const legendY = -10;

    this.addText(legendX, legendY, 'LEGENDA', 3.0, 'LEGEND', 256);
    this.addLine(legendX, legendY - 2, legendX + 3, legendY - 2, 'BOTTOM', 1); // Qizil
    this.addText(legendX + 3.5, legendY - 2, 'Poydevor', 2.0, 'LEGEND', 256);

    this.addLine(legendX, legendY - 4, legendX + 3, legendY - 4, 'WATER', 5); // Ko'k
    this.addText(legendX + 3.5, legendY - 4, 'Suv sathiy', 2.0, 'LEGEND', 256);

    this.addLine(legendX, legendY - 6, legendX + 3, legendY - 6, 'SLOPES', 3); // Yashil
    this.addText(legendX + 3.5, legendY - 6, 'Eğimlar', 2.0, 'LEGEND', 256);
  }

  /**
   * DXF faylni yakunlashtirish
   */
  public end(): string {
    this.content += '0\nENDSEC\n';
    this.content += '0\nEOF\n';
    return this.content;
  }

  /**
   * DXF HEADER bo'limi
   */
  private getHeader(): string {
    return `999
AutoCAD DXF file generated by CrossCAD
0
SECTION
2
HEADER
9
$ACADVER
1
AC1027
9
$EXTMIN
10
-50
20
-50
30
0
9
$EXTMAX
10
500
20
500
30
0
0
ENDSEC
`;
  }

  /**
   * DXF TABLES bo'limi
   */
  private getTables(): string {
    return `0
SECTION
2
TABLES
0
TABLE
2
LAYER
5
0
70
6
0
LAYER
5
10
2
BOTTOM
70
0
62
1
6
CONTINUOUS
0
LAYER
5
11
2
WATER
70
0
62
5
6
DASHED
0
LAYER
5
12
2
SLOPES
70
0
62
3
6
CONTINUOUS
0
LAYER
5
13
2
TOP
70
0
62
7
6
CONTINUOUS
0
LAYER
5
14
2
LABELS
70
0
62
256
6
CONTINUOUS
0
LAYER
5
15
2
NOTES
70
0
62
256
6
CONTINUOUS
0
LAYER
5
16
2
PROFILE_BOTTOM
70
0
62
1
6
CONTINUOUS
0
LAYER
5
17
2
PROFILE_WATER
70
0
62
5
6
DASHED
0
LAYER
5
18
2
PROFILE_DIVISIONS
70
0
62
8
6
DASHED
0
LAYER
5
19
2
PROFILE_MARKERS
70
0
62
1
6
CONTINUOUS
0
LAYER
5
20
2
PROFILE_AXIS
70
0
62
0
6
CONTINUOUS
0
LAYER
5
21
2
PROFILE_LABELS
70
0
62
256
6
CONTINUOUS
0
ENDTBL
0
TABLE
2
LTYPE
5
1
70
21
0
LTYPE
5
2
2
CONTINUOUS
3
Solid line
72
0
73
0
0
LTYPE
5
3
2
DASHED
3
Dashed line _ _ _ _ _ _
72
0
73
2
40
0.625
49
0.5
49
-0.125
0
ENDTBL
0
TABLE
2
STYLE
5
4
70
1
0
STYLE
5
5
2
STANDARD
70
0
40
0
62
256
6
CONTINUOUS
0
ENDTBL
0
ENDTAB
0
ENDSEC
0
SECTION
2
ENTITIES
`;
  }
}

/**
 * CrossCAD-dan DXF export qilish
 */
export function exportToDXF(
  sections: CrossSectionData[],
  filename: string = 'canal_section'
): void {
  const exporter = new DXFExporter();
  exporter.start();

  // Kondalang kesimlarni chizish
  sections.forEach((section) => {
    exporter.drawCrossSection(section);
  });

  // Bo'ylama kesimni chizish
  exporter.drawLongitudinalProfile(sections);

  // Legenda qo'shish
  exporter.addLegend();

  const dxfContent = exporter.end();

  // Fayl yuklash
  const blob = new Blob([dxfContent], { type: 'application/octet-stream' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${filename}.dxf`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

/**
 * DXF faylni matn sifatida qaytarish (embedding uchun)
 */
export function generateDXFString(sections: CrossSectionData[]): string {
  const exporter = new DXFExporter();
  exporter.start();

  sections.forEach((section) => {
    exporter.drawCrossSection(section);
  });

  exporter.drawLongitudinalProfile(sections);
  exporter.addLegend();

  return exporter.end();
}

/**
 * DWG formatida yaratish (advanced - dwg kutubxonasi kerak)
 */
export function exportToDWG(
  sections: CrossSectionData[],
  filename: string = 'canal_section'
): void {
  // Eslatma: DWG uchun dwg-js yoki similar kutubxonasi kerak
  // Hozircha DXF eng oson variant
  console.warn(
    'DWG export DXF-dan ko\'proq kutubxona talab qiladi. DXF fayldan AutoCAD-da o\'tkazish mumkin.'
  );
  exportToDXF(sections, filename);
}

export { DXFExporter };
