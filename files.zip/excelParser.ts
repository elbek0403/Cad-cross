/**
 * ExcelParser - Excel fayllarni to'g'ri parserlash uchun utility
 * 
 * Stantsiyalari taqladi formatni: ПК0+00, ПК2+27, ПК7+49 kabi
 */

import XLSX from 'xlsx';

export interface ParsedCrossSection {
  sta: string;
  distance: number;
  bottom: number;
  water: number;
  width: number;
  depth: number;
  leftSlope: number;
  rightSlope: number;
  description: string;
  rawData?: any;
}

export interface ExcelParseResult {
  success: boolean;
  data: ParsedCrossSection[];
  error?: string;
  warnings?: string[];
}

/**
 * Excel fayldan ma'lumotlarni o'qish va parsing qilish
 * @param file - Yuklangan Excel fayli
 * @returns Parsed ma'lumot yoki xato
 */
export async function parseExcelFile(file: File): Promise<ExcelParseResult> {
  const warnings: string[] = [];

  try {
    // Faylni buffer sifatida o'qish
    const arrayBuffer = await file.arrayBuffer();

    // XLSX bilan faylni o'qish
    const workbook = XLSX.read(arrayBuffer, {
      type: 'array',
      cellFormula: false,
      cellStyles: false,
    });

    // Birinchi listi o'qish
    const sheetName = workbook.SheetNames[0];
    if (!sheetName) {
      return {
        success: false,
        data: [],
        error: 'Excel faylida listi topilmadi',
      };
    }

    const worksheet = workbook.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json(worksheet, {
      header: 'A',
      defval: '',
    });

    // Ma'lumotlarni parsing qilish
    const parsedData: ParsedCrossSection[] = [];

    rows.forEach((row: any, index: number) => {
      try {
        // Stantsiya nomi tekshirish (ПК2+00, ПК7+50 kabi)
        const stationId = String(row.A || '').trim();
        const stationRegex = /^ПК(\d+)\+?(\d*)/;
        const match = stationId.match(stationRegex);

        if (!match) {
          // Skipped - Stantsiya nomi format to'g'ri emas
          if (stationId && stationId !== '') {
            warnings.push(`Qator ${index + 1}: "${stationId}" format ПК+Raqam bo'lishi kerak`);
          }
          return;
        }

        // Masofani hisoblash (ПК2+27 = 200 + 27 = 227)
        const pk = parseInt(match[1]) || 0;
        const offset = parseInt(match[2]) || 0;
        const distance = pk * 100 + offset;

        // Balandliklar o'qish
        const bottomStr = String(row.B || '').trim();
        const waterStr = String(row.C || '').trim();

        const bottom = parseFloat(bottomStr);
        let water = parseFloat(waterStr);

        // Agar suv sathiyy bo'lmasa, standart qiymatidan foydalanish
        if (isNaN(water)) {
          water = bottom + 1.5;
          warnings.push(`Qator ${index + 1}: Suv sathiyy yo'q, standart qiymat (${water.toFixed(2)} m) ishlatildi`);
        }

        // Agar poydevor balandligi noto'g'ri bo'lsa
        if (isNaN(bottom)) {
          warnings.push(`Qator ${index + 1}: Poydevor balandligi raqam emas`);
          return;
        }

        // Eslatma/Tavsif
        const description = String(row.D || '').trim();

        // Kanal o'lchamlari (standart qiymatlar, keyin tahlildan o'tish mumkin)
        // Tavsifdan parametrlarni chiqarish (optional)
        let width = 10; // Standart kanalning ensi (m)
        let depth = 2; // Standart chuqurligi (m)

        // Tavsifdan qo'shimcha parametrlarni ajratish
        if (description) {
          // "Gas tr d=100 mm" formatini taniy olish
          const diameterMatch = description.match(/d=(\d+)\s*mm/i);
          if (diameterMatch) {
            const diameter = parseInt(diameterMatch[1]);
            width = diameter / 1000; // mm -> m
          }

          // "Водапровод ст r=100мм" formatini taniy olish
          const radiusMatch = description.match(/r=(\d+)\s*mm/i);
          if (radiusMatch) {
            const radius = parseInt(radiusMatch[1]);
            width = (radius * 2) / 1000; // mm -> m
          }

          // "Авто мост L=3 м" - most enini o'qish
          const lengthMatch = description.match(/L=([0-9.]+)\s*м/i);
          if (lengthMatch) {
            width = parseFloat(lengthMatch[1]);
          }
        }

        // Yon eğimlar
        const leftSlope = 1.5; // Standart
        const rightSlope = 1.5; // Standart

        // Parsing qilmish ma'lumotni qo'shish
        const parsedSection: ParsedCrossSection = {
          sta: stationId,
          distance,
          bottom,
          water,
          width,
          depth,
          leftSlope,
          rightSlope,
          description,
          rawData: row,
        };

        parsedData.push(parsedSection);
      } catch (err) {
        warnings.push(`Qator ${index + 1}'ni o'qishda xato: ${String(err)}`);
      }
    });

    // Masofalar bo'ylab tartiblash
    parsedData.sort((a, b) => a.distance - b.distance);

    // Tekshirish: Hech qanday ma'lumot yo'qmi?
    if (parsedData.length === 0) {
      return {
        success: false,
        data: [],
        error: 'Excel faylidan stantsiya ma\'lumoti topilmadi. A ustunida ПК+Raqam formatida stantsiyalar bo\'lishi kerak.',
        warnings,
      };
    }

    return {
      success: true,
      data: parsedData,
      warnings: warnings.length > 0 ? warnings : undefined,
    };
  } catch (error) {
    return {
      success: false,
      data: [],
      error: `Excel faylni o'qishda xato: ${String(error)}`,
    };
  }
}

/**
 * Excel ma'lumotlarini validatsiya qilish
 */
export function validateCrossSectionData(
  data: ParsedCrossSection[]
): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (data.length === 0) {
    errors.push('Ma\'lumot bo\'sh');
    return { valid: false, errors };
  }

  if (data.length < 2) {
    errors.push('Kamida 2 stantsiya bo\'lishi kerak');
    return { valid: false, errors };
  }

  data.forEach((section, index) => {
    // Balandliklar tekshirish
    if (isNaN(section.bottom)) {
      errors.push(`Qator ${index}: Poydevor balandligi noto'g'ri`);
    }

    if (isNaN(section.water)) {
      errors.push(`Qator ${index}: Suv sathiy noto'g'ri`);
    }

    // Suv poydevordan yuqorida bo'lishi kerak
    if (section.water < section.bottom) {
      errors.push(`Qator ${index}: Suv sathiy poydevordan past`);
    }

    // O'lchamlar tekshirish
    if (section.width <= 0) {
      errors.push(`Qator ${index}: Kanal ensi 0 dan katta bo'lishi kerak`);
    }

    if (section.depth <= 0) {
      errors.push(`Qator ${index}: Kanal chuqurligi 0 dan katta bo'lishi kerak`);
    }
  });

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Excel faylida qanday ustunlar bo'lishi kerakligini tekshirish
 */
export function checkExcelStructure(file: File): Promise<{
  hasHeaders: boolean;
  columnCount: number;
  rowCount: number;
}> {
  return new Promise((resolve) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        const worksheet = workbook.Sheets[workbook.SheetNames[0]];

        const rows = XLSX.utils.sheet_to_json(worksheet);
        const range = XLSX.utils.decode_range(worksheet['!ref'] || 'A1');

        resolve({
          hasHeaders: rows.length > 0,
          columnCount: range.e.c + 1,
          rowCount: range.e.r + 1,
        });
      } catch {
        resolve({
          hasHeaders: false,
          columnCount: 0,
          rowCount: 0,
        });
      }
    };

    reader.readAsArrayBuffer(file);
  });
}

/**
 * Excel faylidan CSV formatiga o'tkazish
 */
export function exportToCSV(data: ParsedCrossSection[]): string {
  const headers = ['Stantsiya', 'Masofa (m)', 'Poydevor (m)', 'Suv (m)', 'Eni (m)', 'Chuqurligi (m)', 'Tavsif'];
  const rows = data.map((section) => [
    section.sta,
    section.distance.toFixed(2),
    section.bottom.toFixed(2),
    section.water.toFixed(2),
    section.width.toFixed(2),
    section.depth.toFixed(2),
    section.description,
  ]);

  const csv = [
    headers.join(','),
    ...rows.map((row) => row.map((cell) => `"${cell}"`).join(',')),
  ].join('\n');

  return csv;
}

/**
 * CSV fayldan o'qish
 */
export async function parseCSVFile(file: File): Promise<ExcelParseResult> {
  try {
    const text = await file.text();
    const lines = text.split('\n');

    const parsedData: ParsedCrossSection[] = [];

    for (let i = 1; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;

      const cells = line.split(',').map((cell) => cell.replace(/^"|"$/g, ''));

      const sta = cells[0]?.trim() || '';
      const distance = parseFloat(cells[1]) || 0;
      const bottom = parseFloat(cells[2]) || 0;
      const water = parseFloat(cells[3]) || bottom + 1.5;
      const width = parseFloat(cells[4]) || 10;
      const depth = parseFloat(cells[5]) || 2;
      const description = cells[6]?.trim() || '';

      parsedData.push({
        sta,
        distance,
        bottom,
        water,
        width,
        depth,
        leftSlope: 1.5,
        rightSlope: 1.5,
        description,
      });
    }

    return {
      success: true,
      data: parsedData,
    };
  } catch (error) {
    return {
      success: false,
      data: [],
      error: `CSV faylni o'qishda xato: ${String(error)}`,
    };
  }
}

/**
 * JSON fayldan o'qish (tayyorlangan ma'lumot uchun)
 */
export async function parseJSONFile(file: File): Promise<ExcelParseResult> {
  try {
    const text = await file.text();
    const jsonData = JSON.parse(text);

    if (!Array.isArray(jsonData)) {
      return {
        success: false,
        data: [],
        error: 'JSON array bo\'lishi kerak',
      };
    }

    const parsedData: ParsedCrossSection[] = jsonData.map((item: any) => ({
      sta: item.sta || `ПК${item.distance}`,
      distance: item.distance || 0,
      bottom: item.bottom || item.elevation || 0,
      water: item.water || item.bottom + 1.5,
      width: item.width || 10,
      depth: item.depth || 2,
      leftSlope: item.leftSlope || 1.5,
      rightSlope: item.rightSlope || 1.5,
      description: item.description || '',
    }));

    return {
      success: true,
      data: parsedData,
    };
  } catch (error) {
    return {
      success: false,
      data: [],
      error: `JSON faylni o'qishda xato: ${String(error)}`,
    };
  }
}

/**
 * Faylning turini aniqlash va mos parserni ishlatish
 */
export async function parseAnyFile(file: File): Promise<ExcelParseResult> {
  const filename = file.name.toLowerCase();

  if (filename.endsWith('.xlsx') || filename.endsWith('.xls')) {
    return parseExcelFile(file);
  } else if (filename.endsWith('.csv')) {
    return parseCSVFile(file);
  } else if (filename.endsWith('.json')) {
    return parseJSONFile(file);
  } else {
    return {
      success: false,
      data: [],
      error: 'Noto\'g\'ri fayl turi. XLSX, CSV yoki JSON bo\'lishi kerak.',
    };
  }
}
