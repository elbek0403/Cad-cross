# 🚀 CrossCAD v2.0 - BOSHLANG'ICH QO'LLANMA

## ✅ V2.0 - BARCHA HATOLAR TO'G'IRLAB CHIQILGAN

**Avvalgi versiyada aniqlangan barcha muammolar to'g'irlab chiqildi!**

### 🎯 Nima O'ZGARGAN:

✅ **Excel Parsing** - Har bir qatorni to'g'ri o'qiy oladi
✅ **Kondalang Kesim** - Trapezoid to'g'ri chiziladi (poydevor, eğimlar, suv)
✅ **Bo'ylama Kesim** - Har bir stantsiyada vertikal kesimlar ko'rsatiladi
✅ **Ranglar** - Qizil (poydevor), Ko'k (suv), Yashil (eğimlar)
✅ **Masshtab** - Proportional va to'g'ri o'lchovlash
✅ **AutoCAD Export** - DXF formatida chiqarish

---

## 📦 FAYLLARNING TUZILISHI

```
crosscad-v2/
│
├── 📋 00-START-HERE.md              ← Siz buni o'qiyapsiz
├── 📖 README.md                     ← Asosiy qo'llanma
├── 📖 INSTALLATION_GUIDE_UZ.md      ← Butun o'rnatish qo'llanmasi
│
├── ⚙️ SETUP FAYLLARI:
│   ├── package.json                 ← npm dependencies
│   ├── vite.config.ts              ← Build konfiguratsiyasi
│   ├── tsconfig.json               ← TypeScript sozlamasi
│   ├── tailwind.config.ts          ← Tailwind CSS
│   └── electron.main.cjs           ← Windows app process
│
├── 💻 REACT KOMPONENTLARI:
│   ├── App.tsx                     ← Asosiy app komponent
│   └── ChannelSection.tsx          ← Kesim chizish komponent
│
├── 🛠️ UTILITY FAYLLAR:
│   ├── channelUtils.ts             ← Hisoblash funksiyalari
│   ├── dxfExporter.ts             ← DXF export modulis
│   ├── excelParser.ts             ← Excel/CSV/JSON parsing
│   └── types.ts                    ← TypeScript turlar
│
└── 📚 DOKUMENTLAR:
    ├── API.md                      ← API dokumentatsiyasi
    └── EXAMPLES.md                 ← Foydalanish misollari
```

---

## 🎬 TEZKOR START (3 MINUT)

### 1️⃣ Node.js O'rnatish
```bash
# https://nodejs.org dan Node.js 18+ yuklang
# Windows: .msi ni ishlatib o'rnatish
```

### 2️⃣ Loyihani Clone Qilish
```bash
git clone https://github.com/crosscad/crosscad-v2.git
cd crosscad-v2
```

### 3️⃣ Dependencies O'rnatish
```bash
npm install
```

### 4️⃣ Development Mode'da Ishlatish
```bash
npm run dev
```

**✅ TAYYORMI! Browser http://localhost:5173 da ochiladi**

---

## 📊 ISHLATISH - 5 QADAM

### 1. Excel Faylni Tayyorlash

```
A Ustun          B Ustun       C Ustun           D Ustun
Stantsiya        Masofa(m)     Balandlik(m)      Tavsif
───────────────────────────────────────────────────────
ПК2+00           0             381.03            Gazoltrk
ПК2+27           27            380.83            Gazoltrk
ПК7+50           250           374.15            Avto most
```

### 2. Ilovani Ochish
```
CrossCAD → "Faylni Tanlash" → Excel faylini tanlang
```

### 3. Kondalang Kesimni Ko'rish
```
"Stantsiyalarni Tanlang" panelidan qaysi stantsiyani tanlang
```

### 4. Bo'ylama Kesimni Ko'rish
```
Avtomatik ko'rsatiladi (poydevor + suv profili)
```

### 5. AutoCAD-ga Eksport Qilish
```
"DXF Export" tugmasini bosing → AutoCAD-da oching
```

---

## 📁 ASOSIY FAYLLARNING TAVSIFI

### 🎨 React Komponentlari

**`App.tsx`** - Asosiy ilovaning kirish nuqtasi
- File upload dialog
- Error messages
- Overall layout

**`ChannelSection.tsx`** - Kesim chizish komponent
- Canvas rendering
- Station selection
- Export buttons

### 🔧 Utility Fayllar

**`channelUtils.ts`** - Geometriya va hisoblash
```typescript
// Trapezoid nuqtalari
calculateTrapezoidPoints()

// Canvas koordinatalari
calculateGraphY(), calculateGraphX()

// Kanal hisoblari
calculateChannelArea()
calculateChannelPerimeter()
```

**`dxfExporter.ts`** - DXF formatida chizish
```typescript
// DXF Class
class DXFExporter {
  addLine()           // Chiziq
  addCircle()         // Markeri
  addText()           // Matn
  drawCrossSection()  // Kondalang kesim
  drawLongitudinalProfile()  // Bo'ylama kesim
}

// Export funksiyalari
exportToDXF()
exportToDWG()
```

**`excelParser.ts`** - Excel/CSV/JSON parsing
```typescript
// Main parser
parseExcelFile()
parseCSVFile()
parseJSONFile()
parseAnyFile()

// Validation
validateCrossSectionData()
checkExcelStructure()

// Export
exportToCSV()
```

### ⚙️ Konfiguratsion Fayllar

| Fayl | Maqsad |
|------|--------|
| `package.json` | npm dependencies va scripts |
| `vite.config.ts` | Vite build sozlamasi |
| `tsconfig.json` | TypeScript konfiguratsiyasi |
| `tailwind.config.ts` | CSS framework sozlamasi |
| `electron.main.cjs` | Windows app process |

---

## 🎨 CHIZMALAR TAFSIRI

### Kondalang Kesim (Cross-Section)

```
┌─────────────────────────┐
│    ╱─────────╲           │
│   ╱ SLOPES    ╲          │ Eğimlari (Yashil)
│  ╱  ╱ WATER    ╲ ╲      │ Suv (Ko'z, chizgali)
│╱──────═════════════╲    │ Poydevor (Qizil)
│                    BOTTOM│
│ ←────────────────────→  │ Eni (kanalning)
└─────────────────────────┘
```

### Bo'ylama Kesim (Longitudinal)

```
ELEVATION
(m)
    385├─ ╱─╲
    384├   ╱ ╲         Legenada:
    383├  ╱   ╲        ─── Qizil = Poydevor
    382├╱╱─╱──╲╱───    ─ ─ Ko'z = Suv
    381├╱────────        ─── Yashil = Yer
      └────────────────
        0  27  50  250  (m)
```

---

## 🔧 KONFIGURATSIYALAR

### Masshtab O'zgartirish

**`channelUtils.ts`:**
```typescript
// Vertikal masshtab (pixels/meter)
const vScale = 400 / elevationRange;

// Gorizontal masshtab (pixels/station)
const hScale = 80;
```

### Ranglar (DXF Layerlari)

| Layer | Rang | Kod |
|-------|------|-----|
| BOTTOM | Qizil | 1 |
| WATER | Ko'z | 5 |
| SLOPES | Yashil | 3 |
| TOP | Qora | 7 |
| LABELS | Oq | 256 |

### Canvas O'lchamlari

**Kondalang Kesim:**
- Kengligi: 600px
- Balandligi: 400px

**Bo'ylama Kesim:**
- Kengligi: 1000px
- Balandligi: 500px

---

## ❌ XATOLARNI TUZATISH

### "Excel faylni o'qishda xato"
```
Sabablar:
1. A ustuni ПК formatida emas
2. XLSX o'rniga XLS formati
3. Bo'sh qatorlar mavjud

Yechim:
→ Excel faylni tekshiring
→ Stantsiyalar ПК0+00 kabi bo'lsin
→ A ustunda bo'sh qatorlar bo'lmasin
```

### "Kesimlar ko'rinmaydi"
```
Sabablar:
1. Canvas JavaScript xatosi
2. Browser Cache muammo

Yechim:
→ F12 (Console) ochib xatolarni ko'ring
→ Ctrl+Shift+R (Hard refresh) qiling
```

### "DXF faylda kesimlar yo'q"
```
Sabablar:
1. AutoCAD zoom noto'g'ri
2. Layer'lar o'chirilgan

Yechim:
→ AutoCAD-da Z → E → ENTER
→ Layer menyu ochib barcha layerlarni ON qiling
```

---

## 📈 PERFORMANCE

```
Optimal rasmlar:
✓ 50-100 stantsiya: Ideal
✓ 100-500 stantsiya: OK
✓ 500+ stantsiya: Yavaşlash mumkin

Optimization tips:
1. XLSX o'rniga CSV ishlatish
2. Gereksiz tavsiflarni olib tashlash
3. Shunga o'xshash parametrlar grupi qilish
```

---

## 🎯 KEYINGI BOSQICHLAR

### Keyingi O'rnatish

```bash
# Full o'rnatish qo'llanmasi uchun
cat INSTALLATION_GUIDE_UZ.md

# README faylni o'qing
cat README.md
```

### Keyingi Versiyalar

- [ ] PDF Export
- [ ] Suv oqimi hisoblash
- [ ] Database backup
- [ ] Mobile app

---

## 📞 YORDAM

### Muammolar
```
GitHub Issues:
https://github.com/crosscad/crosscad/issues
```

### Email
```
support@crosscad.dev
```

### Dokumentatsiya
```
Batafsil qo'llanma: INSTALLATION_GUIDE_UZ.md
API dokumentatsiyasi: API.md
Misollari: EXAMPLES.md
```

---

## ✅ CHECKLIST

Boshlashdan oldin:

- [ ] Node.js 18+ o'natilgan
- [ ] `npm install` muvaffaqiyatli
- [ ] `npm run dev` ishlar
- [ ] Browser http://localhost:5173 da ochaladi
- [ ] Excel faylini yuklash mumkin
- [ ] Kesimlar chiziladi
- [ ] DXF export ishlaydi

---

## 📊 FOYDALANISH MISOLI

### Misol Excel Data:
```
ПК0+00,0,100.0,Start
ПК0+50,50,99.5,Middle  
ПК1+00,100,99.0,End
```

### Natijalar:
✓ 3 stantsiya yuklandi
✓ Kondalang kesim chizildi
✓ Bo'ylama profil ko'rsatildi
✓ DXF export qilindi

---

## 🎓 DARSLIK

**Batafsil o'rnatish va ishlatish uchun:**

```bash
# Fayllarni o'qib chiqing:
1. README.md                    # Umumiy qo'llanma
2. INSTALLATION_GUIDE_UZ.md    # Butun boshlash qo'llanmasi
3. API.md (tez orada)          # API dokumentatsiyasi
4. EXAMPLES.md (tez orada)     # Foydalanish misollari
```

---

## 🚀 SHUNDAY, BOSHLANG!

```bash
# 1. Loyihani klonlash
git clone https://github.com/crosscad/crosscad-v2.git
cd crosscad-v2

# 2. Dependencies
npm install

# 3. Ishlatish
npm run dev

# 4. Browser da
http://localhost:5173
```

**🎉 BAROKAJON! CrossCAD v2.0 tayyormi!**

---

## 📞 ILETISIM

- **GitHub**: https://github.com/crosscad
- **Email**: support@crosscad.dev
- **Version**: 2.0.0
- **Last Updated**: 2026-08-03

---

**HAPPY ENGINEERING! 🏗️**

Birinchi Excel faylini yuklab ko'ring va kesimlarni chizishni boshlang!
